<?php
require_once "../pwdprak10/koneksi.php";  #lokasi file koneksi.php yang digunakan untuk menghubungkan ke database
$sql = "select * from mahasiswa"; #memanggil perintah menampilkan data dari tabel mahasiswa di sql 
$query = mysqli_query($con, $sql); #Untuk mengirimkan perintah query. Terdiri dari dua parameter yaitu: koneksi, dan SQL
while ($row = mysqli_fetch_assoc($query)) {
    #Mengambil hasil baris sebagai asosiatif , array numerik , atau keduanya. Singkatnya untuk menampung baris tabel menjadi array
    $data[] = $row; #variabel yang akan menampung hasil fungsi  mysql_fetch_assoc()
}
header('content-type: application/json');
echo json_encode($data); #menghasilkan nilai kosong, supaya tidak memunculkan pesan error ketika terjadi error
mysqli_close($con); #digunakan untuk menutup koneksi database yang dibuka sebelumnya
