<?php
$url = "http://localhost/pwdprak10/getdatamhs.php"; # link untuk akses ke halaman getdatamhs.php
$client = curl_init($url); #akan memberikan penangan (handle) berupa fungsi-fungsi untuk meset berbagai opsi (curl_setopt())
curl_setopt($client, CURLOPT_RETURNTRANSFER, 1); # Set Option pada cURL yang berfungsi untuk mengembalikan transfer menjadi bentuk String.
$response = curl_exec($client); #dapatkan halaman URL dan berikan (cetak) ke browser
$result = json_decode($response); #mengubah JSON menjadi array
foreach ($result as $r) { #untuk menampilkan data yang berebentuk array
    echo "<p>";
    echo "NIM : " . $r->nim . "<br />";
    echo "Nama : " . $r->namaMahasiswa . "<br />";
    echo "jenis kel : " . $r->jkel . "<br />";
    echo "Alamat : " . $r->alamat . "<br />";
    echo "Tgl Lahir : " . $r->tgllhr . "<br />";
    echo "</p>";
}
