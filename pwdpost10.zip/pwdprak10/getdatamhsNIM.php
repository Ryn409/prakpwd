<?php

require_once "../pwdprak10/koneksi.php";

$sql 	= "SELECT * FROM mahasiswa WHERE nim='MHS02'";
$query 	= mysqli_query($con, $sql);
while ($row = mysqli_fetch_assoc($query)) {
	$data[] = $row;
}

header('content-type: application/json');
echo json_encode($data);
mysqli_close($con);
