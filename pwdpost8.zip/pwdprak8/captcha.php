<?php
session_start();
$random_alpha = md5(rand()); //perintah untuk membuat kode captcha
$captcha_code = substr($random_alpha, 0, 6); //perintah untuk membuat kode captcha
$_SESSION["captcha_code"] = $captcha_code; //untuk menyimpan captcha yang dibuat
$target_layer = imagecreatetruecolor(70, 30); //pembuatan kode captcha dalam bentuk image 
$captcha_background = imagecolorallocate($target_layer, 255, 160, 119); //membuatan kode captcha dalam bentuk image 
imagefill($target_layer, 0, 0, $captcha_background); //pemberian warna background pada kode captcha
$captcha_text_color = imagecolorallocate($target_layer, 0, 0, 0); //pemberian warna teks pada kode captcha
imagestring($target_layer, 5, 5, 5, $captcha_code, $captcha_text_color); //pemberian warna teks pada kode captcha
header("Content-type: image/jpeg"); //type kode captcha yang dibuat
imagejpeg($target_layer);
