<?php
include '../pwdprak9/koneksi.php'; //untuk menyambungkan dengan file koneksi.php
?>
<h3>Form Pencarian Dengan PHP MAHASISWA</h3>
<form action="" method="get">
    <label>Cari :</label>
    <input type="text" name="cari"> <!-- Menginputkan data yang akan dicari-->
    <input type="submit" value="Cari"> <!-- mengsubmit inputan data yang akan dicari-->
</form>
<?php
if (isset($_GET['cari'])) { //jika kita klik cari, maka yang tampil query cari ini
    $cari = $_GET['cari']; //menampung variabel cari dari form pencarian
    echo "<b>Hasil pencarian : " . $cari . "</b>"; //hasil pencarian
}
?>
<!--Membuat border tabel-->
<table border="1">
    <tr>
        <th>No</th>
        <th>NIM</th>
        <th>Nama</th>
    </tr>
    <?php
    if (isset($_GET['cari'])) { //jika kita klik cari, maka yang tampil query cari ini
        $cari = $_GET['cari']; //menampung variabel cari dari form pencarian
        $sql = "select * from mahasiswa where mahasiswa.nim='$cari'"; //mencari data dengan query
        $tampil = mysqli_query($con, $sql); //untuk menjalankan perintah atau instruksi query ke database MySQL
    } else {
        $sql = "select * from mahasiswa"; //mencari/select data dengan query
        $tampil = mysqli_query($con, $sql); //untuk menjalankan perintah atau instruksi query ke database MySQL
    }
    $no = 1;
    while ($r = mysqli_fetch_array($tampil)) { //melakukan foreach atau perulangan (Memanggil data dari $tampil)
    ?>
        <!--data yang ditampilkan akan di masukan ke dalam tabel berikut -->
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['nim']; ?></td>
            <td><?php echo $r['namaMahasiswa']; ?></td>
        </tr>
    <?php } ?>
</table>