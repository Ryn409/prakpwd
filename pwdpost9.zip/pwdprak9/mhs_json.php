<?php
include "../pwdprak9/koneksi.php"; #lokasi file koneksi.php yang digunakan untuk menghubungkan ke database
$sql = "select * from mahasiswa order by nim"; #memanggil perintah menampilkan data dari user dengan id_user di sql 
$tampil = mysqli_query($con, $sql); #Untuk mengirimkan perintah query. Terdiri dari dua parameter yaitu: koneksi, dan SQL
if (mysqli_num_rows($tampil) > 0) { #Mengambil jumlah baris di dalam tabel.
    $no = 1;
    $response = array();
    $response["data"] = array();
    while ($r = mysqli_fetch_array($tampil)) {
        #Mengambil hasil baris sebagai asosiatif , array numerik , atau keduanya. Singkatnya untuk menampung baris tabel menjadi array
        $h['nim'] = $r['nim']; #menampilkan data nim ke dalam tabel
        $h['namaMahasiswa'] = $r['namaMahasiswa']; #menampilkan data nama mahasiswa ke dalam tabel
        $h['jkel'] = $r['jkel']; #menampilkan data jkel ke dalam tabel
        $h['alamat'] = $r['alamat']; #menampilkan data alamat ke dalam tabel
        $h['tgllhr'] = $r['tgllhr']; #menampilkan data tgllhr ke dalam tabel
        array_push($response["data"], $h); #tambah satu atau lebih elemen pada ujung array
    }
    echo json_encode($response); #menghasilkan nilai kosong, supaya tidak memunculkan pesan error ketika terjadi error
} else {
    $response["message"] = "tidak ada data"; #memunculkan pesan jika data yang dicari tidak ditemukan
    echo json_encode($response); #menghasilkan nilai kosong, supaya tidak memunculkan pesan error ketika terjadi error
}
