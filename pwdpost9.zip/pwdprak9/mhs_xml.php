<?php
include "../pwdprak9/koneksi.php"; #lokasi file koneksi.php yang digunakan untuk menghubungkan ke database
header('Content-Type: text/xml'); #memberikan header pengenal bahwa program tersebut adalah skrip XML
$query = "SELECT * FROM mahasiswa"; #untuk menjalankan perintah atau instruksi query ke database MySQL yang disimpan dalam $mahasiswa
$hasil = mysqli_query($con, $query);  #Untuk mengirimkan perintah query. Terdiri dari dua parameter yaitu: koneksi, dan SQL
$jumField = mysqli_num_fields($hasil); #mengembalikan fungsi jumlah bidang (columns) dalam satu set hasil
echo "<?xml version='1.0'?>"; # menampilkan pengenal Skrip XML ke dalam versi penulisan PHP
echo "<data>"; #fungsi untuk menampilkan data ke layar
while ($data = mysqli_fetch_array($hasil)) {
    #Mengambil hasil baris sebagai asosiatif , array numerik , atau keduanya. Singkatnya untuk menampung baris tabel menjadi array
    echo "<mahasiswa>";
    echo "<nim>", $data['nim'], "</nim>"; #menampilkan data nim ke dalam tabel
    echo "<namaMahasiswa>", $data['namaMahasiswa'], "</namaMahasiswa>"; #menampilkan data nama mahasiswa ke dalam tabel
    echo "<jkel>", $data['jkel'], "</jkel>"; #menampilkan data jkel ke dalam tabel
    echo "<alamat>", $data['alamat'], "</alamat>"; #menampilkan data alamat ke dalam tabel
    echo "<tgllhr>", $data['tgllhr'], "</tgllhr>"; #menampilkan data tgllhr ke dalam tabel
    echo "</mahasiswa>";
}
echo "</data>"; #fungsi untuk menampilkan data ke layar
