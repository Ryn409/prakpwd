<?php
include '../pwdprak9/koneksi.php'; //untuk menyambungkan dengan file koneksi.php
?>

<h3>Form Pencarian DATA KHS Dengan PHP </h3>
<form action="" method="get">
    <label>Cari :</label>
    <input type="text" name="cari"> <!-- Menginputkan data yang akan dicari-->
    <input type="submit" value="Cari"> <!-- mengsubmit inputan data yang akan dicari-->
</form>

<?php
if (isset($_GET['cari'])) {  //jika kita klik cari, maka yang tampil query cari ini
    $cari = $_GET['cari']; //menampung variabel cari dari form pencarian
    echo "<b>Hasil pencarian : " . $cari . "</b>"; //hasil pencarian
}
?>
<!--Membuat border tabel-->
<table border="1">
    <tr>
        <th>No</th>
        <th>NIM</th>
        <th>Nama Mahasiswa</th>
        <th>Kode MK</th>
        <th>Nama Mata Kuliah</th>
        <th>Nilai</th>
    </tr>

    <?php
    if (isset($_GET['cari'])) { //jika kita klik cari, maka yang tampil query cari ini
        $cari     = $_GET['cari']; //menampung variabel cari dari form pencarian
        $sql     = "SELECT  -- mencari data dengan query
							mahasiswa.nim, nilai, namaMahasiswa, kode, namaMK
                            FROM khs INNER JOIN mahasiswa ON khs.NIM=mahasiswa.nim
							INNER JOIN matakuliah ON khs.kodeMK=matakuliah.kode
							WHERE mahasiswa.nim='$cari'";
        //Menggabungkan 3 tabel/inner join 3
        $tampil = mysqli_query($con, $sql); //untuk menjalankan perintah atau instruksi query ke database MySQL
    } else {
        $sql     = "SELECT -- mencari/select data dengan query
                    mahasiswa.nim, nilai, namaMahasiswa, kode, namaMK  
                    FROM khs INNER JOIN mahasiswa ON khs.NIM=mahasiswa.nim
                    INNER JOIN matakuliah ON khs.kodeMK=matakuliah.kode";
        //Menggabungkan 3 tabel/inner join 3
        $tampil = mysqli_query($con, $sql); //untuk menjalankan perintah atau instruksi query ke database MySQL
        // menampung jenis query apapun di dalam nya
    }

    $no = 1;
    while ($r = mysqli_fetch_array($tampil)) { //melakukan foreach atau perulangan (Memanggil data dari $tampil)
    ?>
        <!--data yang ditampilkan akan di masukan ke dalam tabel berikut -->
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $r['nim']; ?></td>
            <td><?php echo $r['namaMahasiswa']; ?></td>
            <td><?php echo $r['kode']; ?></td>
            <td><?php echo $r['namaMK']; ?></td>
            <td><?php echo $r['nilai']; ?></td>
        </tr>

    <?php } ?>

</table>